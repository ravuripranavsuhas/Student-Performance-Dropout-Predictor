@echo off
setlocal
title Student Performance and Dropout Predictor
cd /d "%~dp0"

echo ==============================================
echo Student Performance and Dropout Predictor
echo ==============================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PYTHON=python"
    ) else (
        echo Python was not found.
        echo Please install Python from https://www.python.org/downloads/
        echo During installation, tick "Add Python to PATH".
        pause
        start "" "https://www.python.org/downloads/"
        exit /b 1
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo First-time setup: creating a private Python environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto setup_error
)

echo Checking required libraries. This may take a few minutes the first time...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto setup_error

echo.
echo Starting the website...
echo Your browser should open at http://127.0.0.1:5000
echo Keep this window open while using the website.
start "" http://127.0.0.1:5000
".venv\Scripts\python.exe" app.py
echo.
echo The website has stopped.
pause
exit /b 0

:setup_error
echo.
echo Setup failed. Check your internet connection and confirm Python is installed.
pause
exit /b 1
