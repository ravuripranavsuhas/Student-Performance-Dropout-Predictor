# Student Performance & Dropout Predictor

## Easiest way to run on Windows (no terminal commands)
1. Install Python from https://www.python.org/downloads/ if it is not already installed. During setup, tick **Add Python to PATH**.
2. Extract this ZIP file.
3. Double-click **Run Website.bat**.
4. On the first run, it creates a private environment and installs the libraries; this can take a few minutes and requires an internet connection.
5. Your browser opens at http://127.0.0.1:5000. Keep the black launcher window open while using the site.

If Windows shows a security prompt, only run the file if you trust this project. The batch file runs the local `app.py` included in this folder.

## Features
- Logistic Regression, Decision Tree and Random Forest model comparison.
- Academic-risk estimate and personalised two-week improvement plan.
- CSV upload/retraining and sample CSV download.
- Accuracy, precision, recall and F1 metrics export.

## Important model limitation
Built-in records are fictional and use an academic-risk proxy, not verified dropout outcomes. Do not present the result as confirmed dropout prediction. Use real student data only with permission and suitable privacy protections.
